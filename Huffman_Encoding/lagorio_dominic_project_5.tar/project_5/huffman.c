/*
 This is huffman.c, the og, the bigg hufflepuff, yeet
 ?
 Dominic Lagorio
*/


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<assert.h>
#include<ctype.h>
#include"tree.h"
#include"pack.h"

#define p(x) (((x) - 1)/2)
#define l(x) ((x) * 2 + 1)
#define r(x) ((x) * 2 + 2)

struct tree * leaves[257];

struct tree * heap[257];
int heapcount = 0;
int countc[257];

void count(FILE * );
void inHeap( struct tree * );
void print(struct tree * );
struct tree * deleteMin(void);

int main( int argc, char* argv[]){
    
    
    assert( argc == 3);
    
    int i;
    
    FILE * fp = fopen(argv[1], "rb");
    
    
    
//this lil thing counts the occurences while simultaneuously putting them into the heap
    count(fp);

    
    
// sets up the huffman tree... I think... well, it's supposed to
    struct tree * lc, * rc, * combined;
    while (heapcount > 1){
        
        lc = deleteMin();
        
        
        rc = deleteMin();
        
            
        combined = createTree((getData(lc) + getData(rc)), lc, rc );
       
        
        inHeap(combined);
        
       
        }
    
    
    //print the tree....each character should be paired with its newly encrypted bitcode.
    for (i = 0; i < 257; i++) {
        
        if (leaves[i] != NULL) {
            
            
            if (isprint(i) != 0) {
            
                printf("[%c:\t", i);
            
            }else{
            
                printf("%03o:\t", i);
            }
            printf("%d\t", countc[i]);
            print(leaves[i]);
            printf("]\n");
        }
    }
    
    

    pack(argv[1], argv[2], leaves);
    fclose(fp);
    return 0;
}

//This function counts the number of occurrances of each character in the file

void count(FILE * fp){
    
    int c, i;
    for(i = 0; i < 257; i ++)
        countc[i] = 0;
    
    //counts each character
    while((c = getc(fp)) != EOF){
        countc[c]++;
    }
    
    //sets up the leaves array and the heap at the same time
    for( i = 0 ; i < 257 ; i ++){
        if ( countc[i] != 0){
            leaves[i] = createTree(countc[i], NULL, NULL);
            inHeap(leaves[i]);
        }else
            leaves[i] = NULL;
        
    }
    
    //puts the EOF holder at the end of the array
    leaves[256] = createTree(0, NULL, NULL);
    inHeap(leaves[256]);
    return;
}

//puts an item into the heap

void inHeap( struct tree * new){
    
    //first item case
    if(heapcount == 0){
        heap[0] = new;
        heapcount++;
        return;
    }
    
   
    int index = heapcount ++;
    
    //loops through and finds the correct spot for the item
    while(index > 0 && getData(heap[p(index)]) > getData(new)){
        
        
        heap[index] = heap[p(index)];
        
        index = p(index);

    }
    heap[index] = new;
    return;
}

//beheads the beast! lol it really just deletes the first element as that should be the smallest, but "beheads" sounds waaaaaaay cooler!
struct tree * deleteMin(void){
    
    struct tree * min, *last;
    int index = 0;
    int smaller;
    // replace with the last value
    // move everything down
    
    min = heap[0];
    last = heap[heapcount - 1];
    heap[heapcount - 1] = NULL;
    
    heapcount --;
    
    //moves things around to the right spot
    while (l(index) < heapcount) {
        
        smaller = l(index);
        
       //if the right child exist, then compare the children, then compare the new thing to the smaller child.
         if (r(index) < heapcount){
           
            smaller = ( getData(heap[l(index)]) <= getData(heap[r(index)]) ? l(index): r(index) );
        }
        
        
        // Else just compare with the left child
        if (getData(last) > getData(heap[smaller]) ){
        
            
            heap[index] = heap[smaller];
           
        
            index = smaller;
        
        }else{
        
            break;
        }
        
    }
    
    heap[index] = last;
    
    return min;
}

void print(struct tree * leaf){
// it needs to print the things... you know, the bits and the character... do it recursively
// how do I track the path?
   
   if( getParent(leaf) == NULL || leaf == NULL)
	return;
    
    
   print(getParent(leaf));
    
   if (leaf == (getRight(getParent(leaf)))){
	printf("1");
   }else{
	printf("0");
   }
}

